import streamlit as st
from backend import predict_profile

st.set_page_config(page_title="PersonaShield AI")

st.title("🛡 PersonaShield AI")
st.subheader("Social Identity Scam Detector")

followers = st.number_input("Followers", min_value=0)
following = st.number_input("Following", min_value=0)
posts = st.number_input("Posts", min_value=0)
bio_length = st.number_input("Bio Length", min_value=0)

if st.button("Analyze Profile"):

    trust_score, prediction, explanation = predict_profile(
        followers,
        following,
        posts,
        bio_length
    )

    st.metric("Trust Score", f"{trust_score}%")

    st.write("### Prediction")
    st.success(prediction)

    st.write("### AI Analysis")
    st.write(explanation)