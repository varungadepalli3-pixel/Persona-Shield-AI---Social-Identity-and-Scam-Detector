import google.generativeai as genai

genai.configure(api_key="AQ.Ab8RN6IXNviRg2fP8htGvRwo6drwK86Ub4cwDMGNNd2uhE-WKA")

model = genai.GenerativeModel("gemini-pro")

def predict_profile(followers, following, posts, bio_length):

    trust_score = 100

    if followers < 50:
        trust_score -= 30

    if following > followers * 5:
        trust_score -= 25

    if posts < 5:
        trust_score -= 20

    if bio_length < 10:
        trust_score -= 15

    trust_score = max(0, trust_score)

    if trust_score >= 60:
        prediction = "✅ Genuine Profile"
    else:
        prediction = "⚠️ Suspicious Profile"

    prompt = f"""
    Analyze this social media profile.

    Followers: {followers}
    Following: {following}
    Posts: {posts}
    Bio Length: {bio_length}

    Trust Score: {trust_score}

    Explain why this profile is genuine or suspicious.
    Give safety recommendations.
    """

    response = model.generate_content(prompt)

    return trust_score, prediction, response.text